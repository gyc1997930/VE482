//
//  sort.h
//  lab4_1
//
//  Created by 季星佑 on 2017/10/25.
//  Copyright © 2017年 季星佑. All rights reserved.
//

#ifndef sort_h
#define sort_h

#include "list.h"

int INT_INC( void *a, void *b);

int INT_DEC(void *a,void *b);

int DOUBLE_INC(void *a,void *b);

int DOUBLE_DEC(void *a,void *b);

int STRING_INC(void *a,void *b);

int STRING_DEC(void *a,void *b);

int Random(void *a,void *b);

#endif /* sort_h */
