In this program, I separate the original program into three major layers. 
Namely, the list layer, the reading, sorting and writing layer and the main function layer.
I did not rewrite any codes, but in order to make the division clear, I decided to rearrange the order of my codes a little bit and made some new combinations.